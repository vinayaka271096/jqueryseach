using System.Runtime.CompilerServices;

[assembly:InternalsVisibleTo("GitHub.Tests")]
