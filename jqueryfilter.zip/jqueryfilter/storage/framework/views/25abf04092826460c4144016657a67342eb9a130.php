<!DOCTYPE html>
<html lang = "en">  
   <head>  
   	  <title>Listing of Items</title>
      <meta charset = "utf-8">  
      <meta name = "viewport" content = "width = device-width, initial-scale = 1, shrink-to-fit = no">  
      <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">  
      <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.1/jquery.min.js"></script>
    </head>      
  <link rel = "stylesheet" href = "https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">   
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('/css/style.css')); ?>">  
<body>

<div id="menu">
	<h1 id="section">our Store</h1>
	 <div class="container">

	 	<input type="button" value="ALL" id="all" /> 
	 	<input type="button" value="SWEETS" id="sweetes" /> 
	 	<input type="button" value="CAKES" id="cakes" /> 
	 	<input type="button" value="CUPCAKES" id="cupcakes" /> 
	 	<input type="button" value="DOUGHNUTS" id="doughnuts" /> 



	</div>
	<!-- search bar -->
	<div class="container">  
	  <div class="row mb-5">  
	    <div class="col-lg-8 mx-auto">  
	        <form action="">  
	          <div class="input-group">  
	            <div class="input-group-prepend">  
	              <button id="button-addon8" type="submit" class="btn btn-danger"> <i class="fa fa-search"> </i> </button>  
	            </div>  
	            <input type="search" id="search" placeholder="item..." aria-describedby="button-addon8" class="form-control">  
	          </div>  
	        </form>  
	    </div>  
	  </div>     
	</div>
	<br><br>
	
	<div id="menu_row" class="row">

		<?php $__currentLoopData = $fooditems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>


		<div id="menu_col" class="col-md-4 pb-4 mb-1">
			<div id="box">
				<div class="box">
					<div id="image">
						<a class="text-reset me-3" href="#">


							<?php if(isset($item->image) &&
                            !empty($item->image) &&
                            file_exists(public_path('/images/'.$item->image))): ?>
                            	<img src="<?php echo e(asset('/images/'.$item->image)); ?>" alt="fooditems" width="500" height="600">
	                        <?php else: ?>
	                            <img src="<?php echo e(asset('/images/default_image.jpg')); ?>" alt="fooditems" width="500" height="600">
	                        <?php endif; ?>


     	 				</a>

					</div>
					<div id="below_space">
						<h4><?php echo e($item->name); ?></h4>
						<h4>$<?php echo e($item->price); ?></h4>
						
					</div>
					
				</div>
			</div>
		</div>
		

		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		
		
		


	</div>

	
	
</div>


  
</body>
<script type="text/javascript">


	$("input:button").click(function() {
	    var fired_button = $(this).val();
        getcategorydata(fired_button);
	});

	function getcategorydata(fired_button){
		//alert(fired_button);

        $.ajax({

        url:'<?php echo e(url('get-category-food')); ?>?categoryquery='+fired_button,
        method:'get',
        success:function(data) {
	            console.log(data.categorydata);
	            if (data.categorydata) {
	                $('#menu_row').empty().append(data.categorydata);
	            }else{
	                $('#menu_row').empty().append("<h4 id='nodata'>No Data Found</h4>");
	            }
        	}
    	})

	}
	    // search posts

    $('#search').keyup(function (event) {
        event.preventDefault();
        var query=$(this).val();
        // alert(query);
        fetch_search_data(query);
    });

    function fetch_search_data(query) {

        //alert(query);
        $.ajax({
            url:'<?php echo e(url('get-search-data')); ?>?query='+query,
            method:'get',
            success:function (data) {
                //alert(data.data);
                if (data.categorydata) {
                    $('#menu_row').empty().append(data.categorydata);
                }else{
	                $('#menu_row').empty().append("<h4 id='nodata'>No Data Found</h4>");
	            }
                //console.log(data.data);
            }
        })
        
    }




</script>
</html>