
<?php if(isset($fooditems)): ?>

	<?php $__currentLoopData = $fooditems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

		<div id="menu_col" class="col-md-4 pb-4 mb-1">
			<div id="box">
				<div class="box">
					<div id="image">
						<a class="text-reset me-3" href="#">


							<?php if(isset($item->image) &&
                            !empty($item->image) &&
                            file_exists(public_path('/images/'.$item->image))): ?>
                            	<img src="<?php echo e(asset('/images/'.$item->image)); ?>" alt="fooditems" width="500" height="600">
	                        <?php else: ?>
	                            <img src="<?php echo e(asset('/images/default_image.jpg')); ?>" alt="fooditems" width="500" height="600">
	                        <?php endif; ?>


     	 				</a>

					</div>
					<div id="below_space">
						<h4><?php echo e($item->name); ?></h4>
						<h4>$<?php echo e($item->price); ?></h4>
						
					</div>
					
				</div>
			</div>
		</div>
			

	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php else: ?>
        <h4 id='nodata'>No Data Found</h4>

<?php endif; ?>

		