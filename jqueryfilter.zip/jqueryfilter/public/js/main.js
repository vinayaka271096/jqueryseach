

	$("input:button").click(function() {
	    var fired_button = $(this).val();
	    //alert(fired_button);
        getcategorydata(fired_button);
	});

	function getcategorydata(fired_button){
		alert(fired_button);

		        $.ajax({

                url:'{{ url('get-category-food') }}?categoryquery='+fired_button,
                method:'get',
                success:function(data) {
                    console.log(data.categorydata);
                    if (data.categorydata) {
                        $('#menu_row').empty().append(data.categorydata);
                    }else{
                        $('#menu_row').empty().append("<h4 id='nodata'>No Data Found</h4>");
                    }
                }
            })

	}


