
@if(isset($fooditems))

	@foreach($fooditems as $item)

		<div id="menu_col" class="col-md-4 pb-4 mb-1">
			<div id="box">
				<div class="box">
					<div id="image">
						<a class="text-reset me-3" href="#">


							@if (isset($item->image) &&
                            !empty($item->image) &&
                            file_exists(public_path('/images/'.$item->image)))
                            	<img src="{{ asset('/images/'.$item->image) }}" alt="fooditems" width="500" height="600">
	                        @else
	                            <img src="{{ asset('/images/default_image.jpg') }}" alt="fooditems" width="500" height="600">
	                        @endif


     	 				</a>

					</div>
					<div id="below_space">
						<h4>{{ $item->name }}</h4>
						<h4>${{ $item->price }}</h4>
						
					</div>
					
				</div>
			</div>
		</div>
			

	@endforeach

@else
        <h4 id='nodata'>No Data Found</h4>

@endif

		