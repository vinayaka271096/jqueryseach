﻿using System;
namespace Atlassian.Bitbucket
{
    public enum AuthenticationMethod
    {
        BasicAuth,
        Sso
    }
}

