<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\BakeryFood;
use Illuminate\Support\Facades\DB;


class ViewController extends Controller
{
    // for showing man menu view
    public function showListings(){

    	$fooditems = DB::table('bakery_foods')
    	->join('food_category','food_category.id','=','bakery_foods.category_id')
    	->select('bakery_foods.name','bakery_foods.price','bakery_foods.image','food_category.name AS category')
    	->get();
    	//dd($fooditems);
    	// dd('hello');

    	return view('listingmenu',compact('fooditems'));
    }

    //for showing each category when perticular category applied

    public function eachCategoryList(Request $request){
    	

    	if($request->categoryquery == 'ALL'){

    		$fooditems = DB::table('bakery_foods')
	    	->join('food_category','food_category.id','=','bakery_foods.category_id')
	    	->select('bakery_foods.name','bakery_foods.price','bakery_foods.image','food_category.name AS category')
	    	->get();

	    	$eachCategoryList=view('eachcategory-listing', compact('fooditems'))->render();
        	return response()->json(['categorydata'=>$eachCategoryList]);


    	}
    	elseif ($request->categoryquery == 'SWEETS') {
    		# code...
    		$fooditems = DB::table('bakery_foods')
	    	->join('food_category','food_category.id','=','bakery_foods.category_id')
	    	->select('bakery_foods.name','bakery_foods.price','bakery_foods.image','food_category.name AS category')
	    	->where('food_category.id',1)
	    	->get();

    		$eachCategoryList=view('eachcategory-listing', compact('fooditems'))->render();
        	return response()->json(['categorydata'=>$eachCategoryList]);

    	}

    	elseif ($request->categoryquery == 'CAKES') {
    		# code...

    		$fooditems = DB::table('bakery_foods')
	    	->join('food_category','food_category.id','=','bakery_foods.category_id')
	    	->select('bakery_foods.name','bakery_foods.price','bakery_foods.image','food_category.name AS category')
	    	->where('food_category.id',2)
	    	->get();

    		$eachCategoryList=view('eachcategory-listing', compact('fooditems'))->render();
        	return response()->json(['categorydata'=>$eachCategoryList]);

    	}

    	elseif ($request->categoryquery == 'CUPCAKES') {
    		# code...
    		$fooditems = DB::table('bakery_foods')
	    	->join('food_category','food_category.id','=','bakery_foods.category_id')
	    	->select('bakery_foods.name','bakery_foods.price','bakery_foods.image','food_category.name AS category')
	    	->where('food_category.id',3)
	    	->get();

    		$eachCategoryList=view('eachcategory-listing', compact('fooditems'))->render();
        	return response()->json(['categorydata'=>$eachCategoryList]);

    	}
    	
    	else{

    		$fooditems = DB::table('bakery_foods')
	    	->join('food_category','food_category.id','=','bakery_foods.category_id')
	    	->select('bakery_foods.name','bakery_foods.price','bakery_foods.image','food_category.name AS category')
	    	->where('food_category.id',4)
	    	->get();

			$eachCategoryList=view('eachcategory-listing', compact('fooditems'))->render();
        	return response()->json(['categorydata'=>$eachCategoryList]);

    	}



    }

    // for searching the data

    public function searchEachData(Request $req){

    	//dd($req->query);
    	$fooditems = DB::table('bakery_foods')
	    	->join('food_category','food_category.id','=','bakery_foods.category_id')
	    	->select('bakery_foods.name','bakery_foods.price','bakery_foods.image','food_category.name AS category')
	    	->where('food_category.name','like','%'.$req['query'].'%')
	    	->orwhere('bakery_foods.name','like','%'.$req['query'].'%')
	    	->orwhere('bakery_foods.price','like','%'.$req['query'].'%')
	    	->get();

	    $eachCategoryList=view('eachcategory-listing', compact('fooditems'))->render();
        return response()->json(['categorydata'=>$eachCategoryList]);

    }

}
